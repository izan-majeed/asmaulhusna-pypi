# Asma-Ul-Husna 
A sample python package which gives you access of all the 99 names of Allah.
This package provides 3 tuples and 1 function.
First tuple is named as 'name' which contains 99 names in English literals.
Second tuple is named as 'meaning' which contains corresponding meaning of 'name' in English.
Last tuple is named as 'arabic' which contains all the 99 names in Arabic literals.
Then only fuction named as 'display_nth_name()' takes an integer parameter which ranges from 1 to 99 and prints the nth name of Allah.